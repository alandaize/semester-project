#include <iostream>
#include <string>
#include <ctime>

using namespace std;

int main() {
    const int totalQuestions = 6;
    int totalScore = 0;
    time_t start = time(NULL);
    
    string fullName;
    string studentID;
    string studentClass;


    string questions[] = {
        "What is the capital of Ghana?",
        "How many days are there in a week?",
        "Which religion believes in lesser gods?",
        "How many months are there in a year?",
        "What is the color of the sky?",
        "Name one type of fruit."
    };

    string options[][4] = {
        {"a) Tamale", "b) Accra", "c) Sunyani", "d) Kumasi"},
        {"a) 7", "b) 9", "c) 3", "d) 5"},
        {"a) Islam", "b) Christianity", "c) Traditionalist", "d) None"},
        {"12"},
        {"blue"},
        {"mango"}
    };

    string theoryAnswers[] = {
        "12",
        "blue",
        "mango",
        "12",
        "blue",
        "mango"
    };

    char correctAnswers[] = {'b', 'a', 'c', '-', 'b', '-'};

    cout << "UNIVERSITY OF ENERGY AND NATURAL RESOURCES" << endl;
    cout << "ONLINE EXAMINATION\n";

     cout << ".............................................." << endl;

    cout << "Enter your full name: ";
    getline(cin, fullName);

    cout << "Enter your student ID: ";
    getline(cin, studentID);
    
     cout << "Enter your class: ";
    getline(cin, studentClass);

    // Exam timer
    time_t examStartTime = time(NULL);

    for (int i = 0; i < totalQuestions; ++i) {
        cout << "\nQuestion " << i + 1 << ": " << questions[i] << endl;

        if (i < 3) {
            for (int j = 0; j < 4; ++j) {
                cout << options[i][j] << endl;
            }

            char userAnswer;
            cout << "Enter your answer: ";
            cin >> userAnswer;

            if (userAnswer == correctAnswers[i]) {
                cout << "Correct!\n";
                totalScore++;
            } else {
                cout << "Incorrect.\n";
            }
        } else {
            string userAnswer;
            cin.ignore();
            cout << "Enter your answer: ";
            getline(cin, userAnswer);

            if (userAnswer == theoryAnswers[i]) {
                cout << "Correct!\n";
                totalScore++;
            } else {
                cout << "Incorrect.\n";
            }
        }
    }

    // Calculate exam duration
    time_t examEndTime = time(NULL);
    int examDuration = static_cast<int>(examEndTime - examStartTime);

    cout << "\nExam completed!" << endl;
    cout << "Total Score: " << totalScore << " out of " << totalQuestions << endl;
    cout << "Total Exam Time: " << examDuration << " seconds" << endl;

    // Allow users to leave comments
    string comment;
    cout << "Please leave a comment: ";
    getline(cin, comment);
    cout << "Thank you for your feedback!\n";

    return 0;
}

